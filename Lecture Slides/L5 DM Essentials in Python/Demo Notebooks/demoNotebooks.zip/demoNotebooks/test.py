import sys,os
import csv

if len(sys.argv) < 2 or len(sys.argv) >2:
    print 'Usage: RFtrain.py train_data_size_seq_index'
else:
    seq_index = int(sys.argv[1])

outfile = open('outcsv.csv','wb')
fieldnames = ['train_size','repetition','test_mae','train_time','test_time']

writer = csv.writer(outfile,delimiter=',')
writer.writerow(fieldnames)

print len(sys.argv),seq_index

writer.writerow([seq_index,1,2,3,4])

outfile.close()
